#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX 10
#define BASE2 1
#define BASE16 4

// Prototypes des fonctions
void gen_tab(int arr[], int n);
void copy_tab(int dest[], int src[], int n);
int find_max(int arr[], int n);
int calculate_passages(int max_val, int base_bits);
int calculate_insertions(int n, int base_bits, int passages);
void init_count(int count[], int base);
void fill_count(int count[], int arr[], int n, int shift, int mask);
void accumulate_count(int count[], int base);
void build_output(int output[], int count[], int arr[], int n, int shift, int mask);
void copy_output(int arr[], int output[], int n);
void radix_single_pass(int arr[], int n, int shift, int base_bits);
void radix_simple(int arr[], int n, int base_bits);
void disp_tab(int arr[], int n);
void display_results(const char *message, int passages, int insertions);
double calculate_median(int arr[], int n);

// Fonction principale
int main(void) {
    int arr1[MAX], arr2[MAX];
    int passages_b2, insertions_b2;
    int passages_b16, insertions_b16;

    srand(time(NULL));

    gen_tab(arr1, MAX);
    copy_tab(arr2, arr1, MAX);

    // Tri radix en base 2
    printf("Tri radix en base 2 :\n");
    passages_b2 = calculate_passages(find_max(arr1, MAX), BASE2);
    radix_simple(arr1, MAX, BASE2);
    insertions_b2 = calculate_insertions(MAX, BASE2, passages_b2);
    disp_tab(arr1, MAX);

    // Tri radix en base 16
    printf("Tri radix en base 16 :\n");
    passages_b16 = calculate_passages(find_max(arr2, MAX), BASE16);
    radix_simple(arr2, MAX, BASE16);
    insertions_b16 = calculate_insertions(MAX, BASE16, passages_b16);
    disp_tab(arr2, MAX);

    // Résultats
    printf("\nRésultats des tris :\n");
    display_results("Tri radix en base 2 :", passages_b2, insertions_b2);
    display_results("Tri radix en base 16 :", passages_b16, insertions_b16);

    // Médiane
    printf("\nMédiane du tableau trié en base 2 :\n");
    printf("Médiane : %.2f\n", calculate_median(arr1, MAX));

    return 0;
}

/**
 * @brief Génère un tableau de nombres aléatoires compris entre 1 et 1000.
 * @param arr Tableau à remplir.
 * @param n Taille du tableau.
 */
void gen_tab(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        arr[i] = rand() % 1000 + 1;
    }
}

/**
 * @brief Copie les valeurs d'un tableau source dans un tableau destination.
 * @param dest Tableau de destination.
 * @param src Tableau source.
 * @param n Taille des tableaux.
 */
void copy_tab(int dest[], int src[], int n) {
    for (int i = 0; i < n; i++) {
        dest[i] = src[i];
    }
}

/**
 * @brief Trouve la valeur maximale d'un tableau.
 * @param arr Tableau d'entiers.
 * @param n Taille du tableau.
 * @return La valeur maximale trouvée.
 */
int find_max(int arr[], int n) {
    int max_val = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] > max_val) max_val = arr[i];
    }
    return max_val;
}

/**
 * @brief Calcule le nombre de passages nécessaires pour le tri radix.
 * @param max_val Valeur maximale dans le tableau.
 * @param base_bits Nombre de bits par base.
 * @return Le nombre de passages.
 */
int calculate_passages(int max_val, int base_bits) {
    int passages = 0;
    while (max_val > 0) {
        max_val >>= base_bits;
        passages++;
    }
    return passages;
}

/**
 * @brief Calcule le nombre total d'insertion pour le tri radix.
 * @param n Nombre d'éléments dans le tableau.
 * @param base_bits Nombre de bits par base.
 * @param passages Nombre de passages.
 * @return Le nombre total d'insertion.
 */
int calculate_insertions(int n, int base_bits, int passages) {
    return n * passages;
}

/**
 * @brief Initialise un tableau de comptage à zéro.
 * @param count Tableau de comptage.
 * @param base Taille du tableau de comptage.
 */
void init_count(int count[], int base) {
    for (int i = 0; i < base; i++) {
        count[i] = 0;
    }
}

/**
 * @brief Remplit le tableau de comptage avec les occurrences des chiffres.
 * @param count Tableau de comptage.
 * @param arr Tableau des données.
 * @param n Taille du tableau des données.
 * @param shift Décalage des bits.
 * @param mask Masque pour extraire les bits.
 */
void fill_count(int count[], int arr[], int n, int shift, int mask) {
    for (int i = 0; i < n; i++) {
        int digit = (arr[i] >> shift) & mask;
        count[digit]++;
    }
}

/**
 * @brief Calcule les positions accumulées dans le tableau de comptage.
 * @param count Tableau de comptage.
 * @param base Taille du tableau de comptage.
 */
void accumulate_count(int count[], int base) {
    for (int i = 1; i < base; i++) {
        count[i] += count[i - 1];
    }
}

/**
 * @brief Construit un tableau temporaire trié à partir du tableau de comptage.
 * @param output Tableau temporaire.
 * @param count Tableau de comptage.
 * @param arr Tableau des données.
 * @param n Taille du tableau des données.
 * @param shift Décalage des bits.
 * @param mask Masque pour extraire les bits.
 */
void build_output(int output[], int count[], int arr[], int n, int shift, int mask) {
    for (int i = n - 1; i >= 0; i--) {
        int digit = (arr[i] >> shift) & mask;
        output[--count[digit]] = arr[i];
    }
}

/**
 * @brief Copie le tableau temporaire dans le tableau original.
 * @param arr Tableau original.
 * @param output Tableau temporaire trié.
 * @param n Taille du tableau.
 */
void copy_output(int arr[], int output[], int n) {
    for (int i = 0; i < n; i++) {
        arr[i] = output[i];
    }
}

/**
 * @brief Effectue un seul passage du tri radix.
 * @param arr Tableau des données.
 * @param n Taille du tableau.
 * @param shift Décalage des bits.
 * @param base_bits Nombre de bits par base.
 */
void radix_single_pass(int arr[], int n, int shift, int base_bits) {
    int base = 1 << base_bits;
    int mask = base - 1;
    int count[base];
    int output[n];

    init_count(count, base);
    fill_count(count, arr, n, shift, mask);
    accumulate_count(count, base);
    build_output(output, count, arr, n, shift, mask);
    copy_output(arr, output, n);
}

/**
 * @brief Effectue le tri radix complet.
 * @param arr Tableau des données.
 * @param n Taille du tableau.
 * @param base_bits Nombre de bits par base.
 */
void radix_simple(int arr[], int n, int base_bits) {
    int max_val = find_max(arr, n);
    int shift = 0;

    while ((max_val >> shift) > 0) {
        radix_single_pass(arr, n, shift, base_bits);
        shift += base_bits;
    }
}

/**
 * @brief Affiche les éléments d'un tableau.
 * @param arr Tableau à afficher.
 * @param n Taille du tableau.
 */
void disp_tab(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

/**
 * @brief Affiche les résultats d'un tri.
 * @param message Message décrivant le tri.
 * @param passages Nombre de passages.
 * @param insertions Nombre d'insertions.
 */
void display_results(const char *message, int passages, int insertions) {
    printf("%s\n", message);
    printf("Nombre de passages : %d\n", passages);
    printf("Nombre d'insertions : %d\n", insertions);
}

/**
 * @brief Calcule la médiane d'un tableau trié.
 * @param arr Tableau trié.
 * @param n Taille du tableau.
 * @return La médiane.
 */
double calculate_median(int arr[], int n) {
    if (n % 2 == 0) {
        return (arr[n / 2 - 1] + arr[n / 2]) / 2.0;
    } else {
        return arr[n / 2];
    }
}
